<?php

/**
 * Content Post-Processing
 * 
 * This collection of functions allows you to do whatever post-processing you want on a feed.
 * 
 * If you don't want to do anything to the content, simply return $s. This will ensure that whatever 
 * comes into the function will go back out unmodified.
 */

// We don't want to do anything in the 'none' file, so we'll leave it essentially empty.

?>